
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author pc
 */
public class myconnection_bank {
      public static Connection getConnection(){
    Connection c = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost/bank_project", "root", "12345678");
        } catch (ClassNotFoundException e) {
            System.out.println("ClassNotFoundException" + e);
        } catch (NullPointerException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }
        return c;
    }
}

